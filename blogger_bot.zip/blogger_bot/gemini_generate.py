"""
Generate short TOFU/MOFU/BOFU blog posts with Gemini -> writes posts.json
(blogger_poster.py stays untouched and picks it up).

Setup:  pip install google-genai
        set GEMINI_API_KEY=your_key        (Windows)
        export GEMINI_API_KEY=your_key     (Mac/Linux)

Usage:
  python gemini_generate.py "Topic here"                    # 1 post per stage
  python gemini_generate.py "Topic here" --count 3          # 3 per stage
  python gemini_generate.py "Topic here" --stages tofu mofu # only some stages
  python gemini_generate.py "Topic here" --cta https://yoursite.com --brand "YourBrand"
  add --append to keep existing posts.json entries
"""
import argparse, json, os, re, sys
from pathlib import Path
from google import genai
from google.genai import types

MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
OUT = Path(__file__).parent / "posts.json"

STAGE_BRIEF = {
    "tofu": "TOFU (awareness): beginner-friendly, educational, explains the problem/concept. No hard selling.",
    "mofu": "MOFU (consideration): compares options, gives criteria/how-to-choose, builds trust. Soft mention of the brand.",
    "bofu": "BOFU (decision): why choose {brand}, proof/benefits, objections handled, strong CTA linking to {cta}.",
}

def gen(client, topic, stage, n, brand, cta, seen):
    prompt = f"""Write {n} DIFFERENT short blog post(s) (250-350 words each) about: {topic}
Funnel stage: {STAGE_BRIEF[stage].format(brand=brand, cta=cta)}
Already used titles (avoid repeating): {seen or 'none'}
Rules: valid simple HTML only (<h2>, <p>, <ul><li>, <a>), NO <html>/<body>/<h1>, no markdown, no emojis.
Return ONLY a JSON array: [{{"title": "...", "html": "..."}}]"""
    r = client.models.generate_content(
        model=MODEL, contents=prompt,
        config=types.GenerateContentConfig(response_mime_type="application/json", temperature=0.9))
    txt = re.sub(r"^```(?:json)?|```$", "", r.text.strip()).strip()
    items = json.loads(txt)
    return [{"stage": stage, "title": i["title"].strip(), "html": i["html"].strip()} for i in items]

def main():
    a = argparse.ArgumentParser()
    a.add_argument("topic")
    a.add_argument("--count", type=int, default=1)
    a.add_argument("--stages", nargs="+", default=["tofu", "mofu", "bofu"], choices=list(STAGE_BRIEF))
    a.add_argument("--brand", default="our brand")
    a.add_argument("--cta", default="https://example.com")
    a.add_argument("--append", action="store_true")
    a = a.parse_args()

    key = os.getenv("GEMINI_API_KEY")
    if not key: sys.exit("Set GEMINI_API_KEY env var first.")
    client = genai.Client(api_key=key)

    posts = json.loads(OUT.read_text()) if a.append and OUT.exists() else []
    seen = [p["title"] for p in posts]
    for s in a.stages:
        new = gen(client, a.topic, s, a.count, a.brand, a.cta, seen)
        posts += new; seen += [p["title"] for p in new]
        print(f"{s}: +{len(new)}")
    OUT.write_text(json.dumps(posts, indent=2, ensure_ascii=False))
    print(f"Saved {len(posts)} posts -> posts.json. Now run: python blogger_poster.py post")

if __name__ == "__main__":
    main()
